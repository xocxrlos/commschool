// Simple interactive footer message
document.addEventListener("DOMContentLoaded", () => {
  const footer = document.querySelector("footer p");

  footer.addEventListener("click", () => {
    alert("Welcome to St Huxley's Community College!");
  });
});
